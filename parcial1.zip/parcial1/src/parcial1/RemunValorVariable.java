package parcial1;

public class RemunValorVariable extends Concepto {

    private double porcentaje;

    public RemunValorVariable(int id, String descripcion, double porcentaje) {
        super(id, descripcion);
        this.porcentaje = porcentaje;

    }

    @Override
    public double obtenerImporte(double valor) {
        return valor * (porcentaje / 100.0);
    }

}
