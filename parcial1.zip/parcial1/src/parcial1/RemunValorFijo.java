package parcial1;

public class RemunValorFijo extends Concepto {

    private double minimo;
    private double importe;

    public RemunValorFijo(int id, String descripcion, double minimo, double importe) {
        super(id, descripcion);
        this.minimo = minimo;
        this.importe = importe;
    }

    @Override
    public double obtenerImporte(double valor) {
        double basico = valor;
        if (basico <= minimo) {
            return 0;
        }

        return importe;
    }

}
