package parcial1;

import java.util.ArrayList;

public class Empleado {

    private String nombre;
    private String apellido;
    private String cuil;
    private double valorBase;
    private ESector sector;
    private ArrayList<Concepto> conceptos;

    public Empleado(String cuil, String nombre, String apellido, ESector sector, double valorBase, ArrayList<Concepto> conceptos) {
        this.cuil = cuil;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sector = sector;
        this.valorBase = valorBase;
        this.conceptos = conceptos;

    }

    public String getCuil() {
        return cuil;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public ESector getSector() {
        return sector;
    }

    public double calcularBasico() {
        return valorBase * sector.getCoeficiente();
    }

    public double calcularTotalBruto() {
        double valorTotal = calcularBasico();
        double basico = calcularBasico();
        for (int i = 0; i < conceptos.size(); i++) {
            Concepto c = conceptos.get(i);
            if (!(c.esDeduccion())) {
                valorTotal += c.obtenerImporte(basico);
            }
        }
        return valorTotal;
    }

    public double calcularTotalDeducciones() {
        double valorTotal = 0;
        double bruto = calcularTotalBruto();
        for (int i = 0; i < conceptos.size(); i++) {
            Concepto c = conceptos.get(i);
            if (c.esDeduccion()) {
                valorTotal += c.obtenerImporte(bruto);
            }
        }
        return valorTotal;
    }

    public double calcularSueldoAPagar() {
        return calcularTotalBruto() - calcularTotalDeducciones();

    }
    
public void mostrarConceptos() {
    double basico = calcularBasico();
    double bruto = calcularTotalBruto();

    System.out.println(nombre + " " + apellido);
    System.out.printf("%-5s %-15s %-15s %-15s%n", "id", "Descripción", "Remuneración", "Deducción");
    System.out.printf("%-5d %-15s %-15.2f%n", 1, "Básico", basico);

    for (int i = 0; i < conceptos.size(); i++) {
        Concepto c = conceptos.get(i);
        if (c.esDeduccion()) {
            double importe = c.obtenerImporte(bruto);
            System.out.printf("%-5d %-15s %-15s %-15.2f%n", c.getId(), c.getDescripcion(), "", importe);
        } else {
            double importe = c.obtenerImporte(basico);
            System.out.printf("%-5d %-15s %-15.2f%n", c.getId(), c.getDescripcion(), importe);
        }
    }

    System.out.printf("Sueldo a pagar %.2f%n", calcularSueldoAPagar());
}

@Override
public String toString() {
    return cuil + " - " + nombre + " " + apellido;
}

}
