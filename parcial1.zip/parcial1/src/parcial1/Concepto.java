package parcial1;

public class Concepto {

    private int id;
    private String descripcion;

    public Concepto(int id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;
    }
    
    public int getId(){
        return id;
    }
    
    public String getDescripcion(){
        return descripcion;
    }
    
    public double obtenerImporte(double valor){
        return 0;
    }
    
    public boolean esDeduccion(){
        return false;
    }

}
