package parcial1;

public class Deduccion extends Concepto {

    private double porcentaje;

    public Deduccion(int id, String descripcion, double porcentaje) {
        super(id, descripcion);
        this.porcentaje = porcentaje;
    }

    @Override
    public double obtenerImporte(double valor) {
        return valor * (porcentaje / 100.0);
    }

    @Override
    public boolean esDeduccion() {
        return true;
    }

}
