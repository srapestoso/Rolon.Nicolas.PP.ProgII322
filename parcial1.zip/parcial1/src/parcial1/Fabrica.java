package parcial1;

import java.util.ArrayList;

public class Fabrica {

    private String nombre;
    private ArrayList<Empleado> empleados;

    public Fabrica(String nombre, ArrayList<Empleado> empleados) {
        this.nombre = nombre;
        this.empleados = empleados;
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    private Empleado buscarEmpleado(String cuil) throws CuilInexistenteException {
        for (int i = 0; i < empleados.size(); i++) {
            Empleado e = empleados.get(i);
            if (e.getCuil().equals(cuil)) {
                return e;
            }
        }
        throw new CuilInexistenteException("No existe el empleado con CUIL " + cuil);
    }

    public void mostrarConceptosDeUnEmpleado(String cuil) {
        try {
            Empleado e = buscarEmpleado(cuil);
            e.mostrarConceptos();
        } catch (CuilInexistenteException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void listarSueldoAPagarPorEmpleado() {
        System.out.printf("%-20s %-15s %s%n", "Empleado", "CUIL", "Sueldo a pagar");
        for (int i = 0; i < empleados.size(); i++) {
            Empleado e = empleados.get(i);
            String nombreCompleto = e.getNombre() + " " + e.getApellido();
            System.out.printf("%-20s %-15s %.2f%n", nombreCompleto, e.getCuil(), e.calcularSueldoAPagar());

        }
    }

    public ArrayList<Empleado> obtenerEmpleadosMejorSueldoUnSector(ESector sector) {
        double mayor = 0;
        for (int i = 0; i < empleados.size(); i++) {
            Empleado e = empleados.get(i);
            if (e.getSector() == sector && e.calcularSueldoAPagar() > mayor) {
                mayor = e.calcularSueldoAPagar();
            }
        }

        ArrayList<Empleado> mejores = new ArrayList<>();
        for (int i = 0; i < empleados.size(); i++) {
            Empleado e = empleados.get(i);
            if (e.getSector() == sector && e.calcularSueldoAPagar() == mayor) {
                mejores.add(e);
            }
        }
        return mejores;
    }
}
