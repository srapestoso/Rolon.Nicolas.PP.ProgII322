package parcial1;

public enum ESector {
    ADMINISTRACION(1.0), VENTAS(1.2), PRODUCCION(1.5);

    private double coeficiente;

    ESector(double coeficiente) {
        this.coeficiente = coeficiente;
    }

    public double getCoeficiente() {
        return coeficiente;
    }

}
