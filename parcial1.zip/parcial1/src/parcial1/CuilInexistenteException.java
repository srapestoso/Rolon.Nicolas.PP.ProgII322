package parcial1;

public class CuilInexistenteException extends Exception {

    public CuilInexistenteException(String mensaje) {

        super(mensaje);
    }

}
