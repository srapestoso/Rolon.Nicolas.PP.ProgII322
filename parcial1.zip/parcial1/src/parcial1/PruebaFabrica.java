package parcial1;

import java.util.ArrayList;

/**
 *
 * @author Marcelo
 */
public class PruebaFabrica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /*  colecciones para usar en los constructores*/
        ArrayList<Empleado> empleados = new ArrayList<Empleado>();
        ArrayList<Concepto> conceptosDeUnEmpleado = new ArrayList<Concepto>();

        /*  modificar la construcción de conceptos con los 
    nombres definidos por ustedes...*/
        Concepto concepto1 = new RemunValorFijo(1, "Presentismo", 30000, 10000);
        Concepto concepto2 = new RemunValorVariable(2, "Premio", 3);
        Concepto concepto3 = new Deduccion(3, "Jubilacion", 11);
        Concepto concepto4 = new Deduccion(4, "Obra social", 3);
        Concepto concepto5 = new Deduccion(5, "Cuota sindical", 2);

        /*  una vez definidos los conceptos, creamos a cada empleado
    asignando en ese momento sus conceptos.*/
        conceptosDeUnEmpleado.add(concepto1);
        conceptosDeUnEmpleado.add(concepto2);
        conceptosDeUnEmpleado.add(concepto3);
        conceptosDeUnEmpleado.add(concepto4);
        empleados.add(new Empleado("20-12345678-1", "juan", "perez", ESector.ADMINISTRACION, 100000, conceptosDeUnEmpleado));

        conceptosDeUnEmpleado = new ArrayList<Concepto>();
        conceptosDeUnEmpleado.add(concepto1);
        conceptosDeUnEmpleado.add(concepto3);
        conceptosDeUnEmpleado.add(concepto4);
        empleados.add(new Empleado("20-12345678-2", "arturo", "lopez", ESector.ADMINISTRACION, 110000, conceptosDeUnEmpleado));

        conceptosDeUnEmpleado = new ArrayList<Concepto>();
        conceptosDeUnEmpleado.add(concepto1);
        conceptosDeUnEmpleado.add(concepto2);
        conceptosDeUnEmpleado.add(concepto3);
        conceptosDeUnEmpleado.add(concepto4);
        conceptosDeUnEmpleado.add(concepto5);
        empleados.add(new Empleado("20-12345678-3", "lola", "mentovich", ESector.ADMINISTRACION, 130000, conceptosDeUnEmpleado));

        conceptosDeUnEmpleado = new ArrayList<Concepto>();
        conceptosDeUnEmpleado.add(concepto1);
        conceptosDeUnEmpleado.add(concepto2);
        conceptosDeUnEmpleado.add(concepto3);
        empleados.add(new Empleado("20-12345678-4", "estela", "drillazo", ESector.VENTAS, 110000, conceptosDeUnEmpleado));

        Fabrica miFabrica = new Fabrica("la piadosa", empleados);

        /*      ya está todo creado, ahora a probarlo*/
        miFabrica.listarSueldoAPagarPorEmpleado();
        System.out.println("COncetpos de un emplado!!");
        miFabrica.mostrarConceptosDeUnEmpleado("20-12345678-3");
        ArrayList<Empleado> empleados2 = miFabrica.obtenerEmpleadosMejorSueldoUnSector(ESector.ADMINISTRACION);
        System.out.println("Mejor sueldo");
        for (Empleado em : empleados2) {
            System.out.println(em);
        }

        miFabrica.mostrarConceptosDeUnEmpleado("20-12345678-44");
        System.out.println("gracias por usar nuestro programa!!");
    }

}
