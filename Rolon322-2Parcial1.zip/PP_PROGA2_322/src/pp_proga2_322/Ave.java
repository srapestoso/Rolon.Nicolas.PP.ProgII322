package pp_proga2_322;

public class Ave extends Animal implements Liberable, Rehabilitable {
    private final double envergaduraAlar;
    
    public Ave(String codigo, String nombre, EstadoSalud estado,double envergaduraAlar) {
        super(codigo, nombre, estado);
        validarPositivo(envergaduraAlar);
        this.envergaduraAlar = envergaduraAlar;
    }
    
    @Override
    public double costoDiario(){
        return envergaduraAlar * 2;
    }

    @Override
    public String reabilitar() {
        if(getEstado() != EstadoSalud.ESTABLE){
            throw new IllegalStateException("No está apto para ser liberado");
        }
        return "Rehabilitando a " + getNombre();
    }

    @Override
    public String liberar() {
        if(getEstado() != EstadoSalud.ESTABLE){
            throw new IllegalStateException("No está apto para ser liberado");
        }
        return "Liberando a " + getNombre();
    }
}
