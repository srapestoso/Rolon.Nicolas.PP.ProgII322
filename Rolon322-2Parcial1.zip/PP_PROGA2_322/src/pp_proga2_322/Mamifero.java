package pp_proga2_322;

public class Mamifero extends Animal implements Rehabilitable{
    private final double peso;

    public Mamifero(String codigo, String nombre, EstadoSalud estado,double peso) {
        super(codigo, nombre, estado);
        validarPositivo(peso);
        this.peso = peso;
    }    
    
    @Override
    public double costoDiario(){
        return peso * 10;
    }

    @Override
    public String reabilitar() {
        if(getEstado() != EstadoSalud.ESTABLE){
            throw new IllegalStateException("No está apto para ser liberado");
        }
        return "Rehabilitando a " + getNombre();
    }
}
