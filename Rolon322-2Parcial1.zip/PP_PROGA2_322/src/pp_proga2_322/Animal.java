package pp_proga2_322;

import java.util.Objects;


public abstract class Animal {
    
    private String codigo;
    private String nombre;
    private EstadoSalud estado;

    public Animal(String codigo, String nombre, EstadoSalud estado) {
        validarDatos(codigo);
        validarDatos(nombre);
        Objects.requireNonNull(estado);
        this.codigo = codigo;
        this.nombre = nombre;
        this.estado = estado;
    }
    
    private void validarDatos(String dato){
        if(dato == null || dato.isEmpty()){
            throw new IllegalArgumentException("Dato invalido");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public EstadoSalud getEstado() {
        return estado;
    }
    
    public String getCodigo(){
        return codigo;
    }
    
    protected void validarPositivo(double dato){
        if(dato <= 0){
            throw new IllegalArgumentException("Dato invalido");
        }
    }

    @Override
    public String toString() {
        return "{" + "codigo=" + codigo + ", nombre=" + nombre + ", estado=" + estado + '}';
    }
    
    
        
    public abstract double costoDiario();    
    
    
}
