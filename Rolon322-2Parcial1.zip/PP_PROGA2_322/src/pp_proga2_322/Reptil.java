package pp_proga2_322;

public class Reptil extends Animal implements Liberable{
    
    private final double longitud;
    
    
    /**
     * Constructor de la clase Ave
     * @param codigo identificador del animal
     * @param nombre del animal
     * @param estado de salud del animal
     * @param longitud del animal
     */
    public Reptil(String codigo, String nombre, EstadoSalud estado,double longitud) {
        super(codigo, nombre, estado);
        validarPositivo(longitud);
        this.longitud = longitud;
    }    
    
    
    /**
     * Calcula el costo diario del mamifero
     * @return double con el total
     */
    @Override
    public double costoDiario(){
        return longitud + 15;
    }
    
    /**
     * Realiza el proceso de liberacion
     * @return String aclarando que se está liberando el animal
     * @throws IllegalStateException si el animal no tiene salud ESTABLE y requiere de rehabilitacion
     */
    @Override
    public String liberar() {
        if(getEstado() != EstadoSalud.ESTABLE){
            throw new IllegalStateException("No está apto para ser liberado");
        }
        return "Liberando a " + getNombre();
    }
}
