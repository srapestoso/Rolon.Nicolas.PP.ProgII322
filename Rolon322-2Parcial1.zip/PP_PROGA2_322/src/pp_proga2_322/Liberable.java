package pp_proga2_322;

public interface Liberable {
    
    String liberar();
    
}
