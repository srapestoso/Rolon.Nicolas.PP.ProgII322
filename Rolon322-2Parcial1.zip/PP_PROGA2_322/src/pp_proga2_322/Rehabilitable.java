package pp_proga2_322;


public interface Rehabilitable {
    
    /**
     * Realiza el proceso de rehabilitacion del animal
     * @return Un mensaje indicando el resultado de la rehabilitacion
     */
    String reabilitar();
}
