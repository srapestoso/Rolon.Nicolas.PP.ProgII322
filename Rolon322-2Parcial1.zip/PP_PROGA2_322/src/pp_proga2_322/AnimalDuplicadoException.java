package pp_proga2_322;


public class AnimalDuplicadoException extends Exception {
    
    public AnimalDuplicadoException(){
        super();
    }
    
    public AnimalDuplicadoException(String mensaje){
        super(mensaje);
    }
}
